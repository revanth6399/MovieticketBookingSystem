
<!DOCTYPE html>
<html>
	<head>
		<title>Welcome</title>
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

				<!-- Optional theme -->
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

				<!-- Latest compiled and minified JavaScript -->
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


		<style >
			h2,h4,,h5,h3{
				color: black;
				
				}
			body{
				background-image: url("images/welcome.jpg");
				background-repeat: no-repeat;
				background-size:cover;
			}
			p{
				font-family: times;
			}
			
		</style>

		<section class="main-container" >
			<div class="main-wrapper">
				<center><h4 style="font-size: 400%;font-family: comic sans ms; padding-top: 3%;"><u><b>MOVIE TICKET BOOKING DATABASE</b></u></h4><br></center>
				<h5 style="font-size: 300%; font-family:  comic sans ms; font-style: italic; padding-top:0.25%; padding-bottom: 0.35%;">
				<center><u><b>Project by:</b></u> <br></center></h5>
				<h3 style="font-size: 250%; font-family:  comic sans ms; font-style: italic; padding-top:0.25%; padding-bottom: 0.7%; "><b><center>
					Name: Aditya Warrier <br> Usn:1AT15IS002<br>
					Name: Dimple K H  <br>  Usn:1AT15IS025<br>
					Semester:5th<br>
					Branch: ISE<br>
					College: Atria Institute of Technology</center>
				</b></h3>
			</div>
		</section>
		<body style="background-color:#707B7C">
			<ul><br><center><a href="index1.php" class="btn btn-warning btn-lg" style="font-size:15px;  font-family: comic sans ms; color: black" role="button"><b>Click here</b></a></center></u>
		</body>
	</head>
</html>